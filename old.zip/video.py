from tkinter import *
from tkvideo import tkvideo

root = Tk()
root.geometry('1200x800+0+0')
root.attributes('-fullscreen',True)
root.config(bg='white')
my_label = Label(root,bg='white')
my_label.place(x=400,y=230)
player = tkvideo("video/107013-loader-for-wi-fi-connection.mp4", my_label, loop = 1, size = (350,350))
player.play()

root.mainloop()