from tkinter import messagebox
import threading
import socket
import time
from urllib import request
from tkinter import *
from tkvideo import tkvideo


def check_connection():
    try:
        request.urlopen("https://www.google.com/",timeout=5)
        global connection
        connection='online'
        print(connection)
        def main_body():
            main_body=Tk()
            main_body.geometry('500x600')
            l=Label(main_body,text=connection)
            l.pack()
            main_body.mainloop()
        main_body()
    except OSError:
        connection='ofline'
        print(connection)
        def second_body():
            second_body=Tk()
            second_body.geometry('1080x920')
            second_body.attributes('-fullscreen',True)
            second_body.config(bg='white')
            my_label = Label(second_body,bg='white')
            my_label.place(x=160,y=150)
            player = tkvideo("video/107013-loader-for-wi-fi-connection.mp4", my_label, loop = 1, size = (500,500))
            player.play()
            def notconnect():
                second_body.destroy()
                ifnot()
            

            nosig_img=PhotoImage(file='button/nosignal.png')
            nosig_label=Label(second_body,image=nosig_img,bd=0,bg='white')
            nosig_label.place(x=870,y=235)

            re_img=PhotoImage(file='button/retry.png')
            re_button=Button(second_body,image=re_img,command=notconnect,bg='white',activebackground='white',bd=0,cursor='hand2')
            re_button.place(x=1035,y=515)
        
            second_body.mainloop()
        second_body()
def ifnot():
    check_connection()
check_connection()