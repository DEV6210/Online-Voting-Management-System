import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
 
root= tk.Tk()
  
canvas1 = tk.Canvas(root, width = 800, height = 300)
canvas1.pack()


  
def create_charts():      
    figure2 = Figure(figsize=(4,3), dpi=100) 
    subplot2 = figure2.add_subplot(111) 

    labels2 = 'Label1', 'Label2', 'Label3' 
    pieSizes = [float(5),float(6),float(7)]
    my_colors2 = ['lightblue','lightsteelblue','silver']    
    explode2 = (0, 0, 0)  

    subplot2.pie(pieSizes, colors=my_colors2, explode=explode2, labels=labels2, autopct='%1.1f%%', shadow=True, startangle=90) 
    
    
    pie2 = FigureCanvasTkAgg(figure2, root)
    pie2.get_tk_widget().pack()

            
button1 = tk.Button (root, text=' Create Charts ',command=create_charts, bg='palegreen2', font=('Arial', 11, 'bold')) 
canvas1.create_window(400, 180, window=button1)
 
root.mainloop()