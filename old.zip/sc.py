import matplotlib.pyplot as plt
from tkinter import *
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
 

root=Tk()

figure2=Figure(figsize=(5,5),dpi=100)
subplot2=figure2.add_subplot(111)

vot_per=[4,2,2]
party_name=['BJP','TMC','CONGRESS']
exp=[0,0,0]
color_pi=['red','green','yellow']
f=plt.figure()

subplot2.pie(vot_per, labels=party_name, explode=exp, autopct='%2.1f%%', colors=color_pi)
pie2=FigureCanvasTkAgg(figure2,root)
pie2.get_tk_widget().place(x=10,y=20)

root.mainloop()
